# GEMINI.md: Research Desk

The full project context and rules are in `AGENTS.md` at the repository root. Read `AGENTS.md` completely before any task, plan or code change, and follow it exactly. Then read the docs that `AGENTS.md` section 9 lists for your task.

If anything in this file conflicts with `AGENTS.md`, stop and ask me. Do not choose silently.
